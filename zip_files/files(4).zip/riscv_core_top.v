// Single-cycle RV32I core - M1 milestone
// Wires together: pc_reg, imem, control_unit, imm_gen, regfile, alu_control,
// alu, dmem. No pipelining yet - each instruction fully completes in one
// clock cycle, so there are no data/control hazards to handle at this stage.

module riscv_core_top (
    input wire clk,
    input wire rst_n
);

    localparam OPC_JAL  = 7'b1101111;
    localparam OPC_JALR = 7'b1100111;

    wire [31:0] pc, pc_next, pc_plus4, instr;

    // Instruction field decode
    wire [6:0] opcode   = instr[6:0];
    wire [4:0] rd_addr  = instr[11:7];
    wire [2:0] funct3   = instr[14:12];
    wire [4:0] rs1_addr = instr[19:15];
    wire [4:0] rs2_addr = instr[24:20];
    wire       funct7_5 = instr[30];

    // Control signals
    wire       reg_write, alu_src, mem_read, mem_write, branch, jump;
    wire [1:0] alu_src_a, result_src, alu_op;

    wire [31:0] imm;
    wire [31:0] rs1_data, rs2_data;
    wire [3:0]  alu_ctrl;
    wire [31:0] alu_a, alu_b, alu_result;
    wire        alu_zero;
    wire [31:0] mem_read_data;
    wire [31:0] write_back_data;
    wire [31:0] branch_target, jalr_target;
    reg         branch_taken_r;
    wire        branch_taken;

    // --- Fetch ---
    pc_reg pc_reg_inst (
        .clk(clk), .rst_n(rst_n), .pc_next(pc_next), .pc(pc)
    );

    imem imem_inst (
        .addr(pc), .instr(instr)
    );

    assign pc_plus4     = pc + 32'd4;
    assign branch_target = pc + imm; // reused for both branches and JAL

    // --- Decode ---
    control_unit control_inst (
        .opcode(opcode),
        .reg_write(reg_write), .alu_src(alu_src), .alu_src_a(alu_src_a),
        .mem_read(mem_read), .mem_write(mem_write), .result_src(result_src),
        .branch(branch), .jump(jump), .alu_op(alu_op)
    );

    imm_gen imm_gen_inst (
        .instr(instr), .imm(imm)
    );

    regfile regfile_inst (
        .clk(clk), .rst_n(rst_n),
        .we(reg_write), .rs1_addr(rs1_addr), .rs2_addr(rs2_addr),
        .rd_addr(rd_addr), .rd_data(write_back_data),
        .rs1_data(rs1_data), .rs2_data(rs2_data)
    );

    // --- Execute ---
    alu_control alu_control_inst (
        .alu_op(alu_op), .funct3(funct3), .funct7_5(funct7_5),
        .alu_ctrl(alu_ctrl)
    );

    // ALU operand A: rs1 (default), PC (AUIPC), or zero (LUI)
    assign alu_a = (alu_src_a == 2'b01) ? pc :
                   (alu_src_a == 2'b10) ? 32'd0 :
                   rs1_data;

    // ALU operand B: rs2 (R-type/branch) or immediate (everything else)
    assign alu_b = alu_src ? imm : rs2_data;

    alu alu_inst (
        .a(alu_a), .b(alu_b), .alu_op(alu_ctrl),
        .result(alu_result), .zero(alu_zero)
    );

    // JALR target: rs1 + imm, with LSB cleared per spec
    assign jalr_target = {alu_result[31:1], 1'b0};

    // Branch condition evaluation - reuses ALU result computed above
    always @(*) begin
        case (funct3)
            3'b000:  branch_taken_r = alu_zero;       // BEQ
            3'b001:  branch_taken_r = ~alu_zero;      // BNE
            3'b100:  branch_taken_r = alu_result[0];  // BLT  (SLT result)
            3'b101:  branch_taken_r = ~alu_result[0]; // BGE
            3'b110:  branch_taken_r = alu_result[0];  // BLTU (SLTU result)
            3'b111:  branch_taken_r = ~alu_result[0]; // BGEU
            default: branch_taken_r = 1'b0;
        endcase
    end
    assign branch_taken = branch & branch_taken_r;

    // --- Memory ---
    dmem dmem_inst (
        .clk(clk), .mem_read(mem_read), .mem_write(mem_write),
        .addr(alu_result), .write_data(rs2_data), .funct3(funct3),
        .read_data(mem_read_data)
    );

    // --- Write-back ---
    assign write_back_data = (result_src == 2'b01) ? mem_read_data :
                              (result_src == 2'b10) ? pc_plus4 :
                              alu_result; // result_src == 2'b00

    // --- Next PC selection ---
    assign pc_next = (jump && opcode == OPC_JAL)  ? branch_target :
                      (jump && opcode == OPC_JALR) ? jalr_target :
                      (branch_taken)               ? branch_target :
                      pc_plus4;

endmodule
